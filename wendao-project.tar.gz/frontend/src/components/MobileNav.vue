<template>
  <nav class="mobile-nav">
    <router-link to="/" class="nav-item" active-class="active">
      <svg class="nav-icon" viewBox="0 0 24 24">
        <path d="M21.63 8.48l-8.01-6.29c-.89-.7-2.35-.7-3.24 0L2.37 8.48c-.79.62-.79 1.64 0 2.26l8.01 6.29c.89.7 2.35.7 3.24 0l8.01-6.29c.79-.62.79-1.64 0-2.26zM12 15.45l-6.94-5.45L12 4.55l6.94 5.45L12 15.45z M12 17.5v3 M8 18.5v2 M16 18.5v2" />
      </svg>
      <span class="nav-text">斋堂</span>
    </router-link>
    
    <router-link to="/history" class="nav-item" active-class="active">
      <svg class="nav-icon" viewBox="0 0 24 24">
        <path d="M12 2c5.52 0 10 4.48 10 10s-4.48 10-10 10S2 17.52 2 12 6.48 2 12 2z M12 6v6l4 2" />
        <path d="M12 8c2.76 0 5 2.24 5 5s-2.24 5-5 5-5-2.24-5-5 2.24-5 5-5z M12 10v3l2 1" stroke="currentColor" fill="none" stroke-width="1.5" />
      </svg>
      <span class="nav-text">签录</span>
    </router-link>
  </nav>
</template>

<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()
</script>

<style scoped>
.mobile-nav {
  display: none;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 64px;
  background: #F3F7F7;
  box-shadow: 0 -1px 12px rgba(108, 124, 124, 0.06);
  padding: 0 1rem;
  z-index: 100;
  backdrop-filter: blur(8px);
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  color: #6C7C7C;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  flex: 1;
  position: relative;
  padding: 0.5rem 0;
}

.nav-icon {
  width: 28px;
  height: 28px;
  margin-bottom: 4px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  opacity: 0.85;
}

.nav-text {
  font-size: 13px;
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  letter-spacing: 0.1em;
}

.nav-item.active {
  color: #4A6363;
}

.nav-item.active .nav-icon {
  opacity: 1;
  transform: scale(1.1);
}

.nav-item.active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 24px;
  height: 2px;
  background: linear-gradient(90deg, 
    transparent,
    rgba(74, 99, 99, 0.8),
    transparent
  );
  border-radius: 1px;
}

@media (max-width: 767px) {
  .mobile-nav {
    display: flex;
    align-items: center;
    justify-content: space-around;
  }
}
</style> 