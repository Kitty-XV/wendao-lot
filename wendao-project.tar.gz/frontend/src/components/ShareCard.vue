<template>
  <div class="share-wrapper" v-if="visible">
    <div class="share-content">
      <div class="share-header">
        <h3 class="share-title">分享签文</h3>
        <button class="close-btn" @click="$emit('close')">
          <svg viewBox="0 0 24 24" class="close-icon">
            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
          </svg>
        </button>
      </div>

      <div class="card-preview" ref="cardRef">
        <div class="header-wrapper">
          <div class="sign-info">
            <span class="sign-number">第{{ toChineseNumber(signNumber) }}签</span>
            <span class="sign-name">[{{ signName }}]</span>
          </div>
          <div class="date-wrapper">
            <div class="date-text">{{ lunarDate }}</div>
            <div class="year-text">{{ lunarYear }}</div>
          </div>
        </div>
        
        <div class="poem-section">
          <p class="poem">{{ poem }}</p>
        </div>
        
        <div class="divider"></div>
        
        <div class="interpretation-section">
          <p class="interpretation">【解签】{{ interpretation }}</p>
        </div>
        
        <div class="footer">
          <div class="qrcode">
            <QRCode
              :value="qrCodeValue"
              :size="48"
              level="M"
              render-as="svg"
              :margin="0"
              class="qr-code"
              :foreground="'#B4A162'"
              :background="'transparent'"
            />
          </div>
          <p class="footer-text">问道阁 · 在线求签</p>
        </div>
      </div>

      <div class="share-actions">
        <button class="action-btn save" @click="handleSave">
          <svg viewBox="0 0 24 24" class="action-icon">
            <path d="M19 12v7H5v-7H3v7c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-7h-2zm-6 .67l2.59-2.58L17 11.5l-5 5-5-5 1.41-1.41L11 12.67V3h2z"/>
          </svg>
          <span>保存图片</span>
        </button>
        
        <button class="action-btn copy" @click="handleCopy">
          <svg viewBox="0 0 24 24" class="action-icon">
            <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
          </svg>
          <span>复制文字</span>
        </button>
        
        <button class="action-btn forward" @click="handleForward">
          <svg viewBox="0 0 24 24" class="action-icon">
            <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92z"/>
          </svg>
          <span>转发</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import html2canvas from 'html2canvas'
import { Lunar } from 'lunar-javascript'
import QRCode from 'qrcode.vue'
import { ElMessage } from 'element-plus'

const props = defineProps({
  visible: Boolean,
  signNumber: {
    type: [Number, String],
    default: 1
  },
  signName: {
    type: String,
    default: '乾元'
  },
  poem: String,
  interpretation: String
})

const cardRef = ref(null)
const isLoading = ref(false)

const lunarYear = computed(() => {
  const lunar = Lunar.fromDate(new Date())
  return `${lunar.getYearInGanZhi()}年`
})

const lunarDate = computed(() => {
  const lunar = Lunar.fromDate(new Date())
  return `${lunar.getMonthInChinese()}月${lunar.getDayInChinese()}`
})

const toChineseNumber = (num) => {
  const chineseNumbers = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
  const number = parseInt(num)
  
  if (number <= 10) {
    return chineseNumbers[number]
  } else if (number < 20) {
    return '十' + (number % 10 === 0 ? '' : chineseNumbers[number % 10])
  } else if (number < 100) {
    const tens = Math.floor(number / 10)
    const ones = number % 10
    return chineseNumbers[tens] + '十' + (ones === 0 ? '' : chineseNumbers[ones])
  }
  return num.toString()
}

const handleSave = async () => {
  if (!cardRef.value) return
  try {
    isLoading.value = true
    const canvas = await html2canvas(cardRef.value, {
      backgroundColor: null,
      scale: 3,
      useCORS: true,
      logging: false
    })
    const link = document.createElement('a')
    link.download = `玉签阁-${lunarYear.value}${lunarDate.value}.png`
    link.href = canvas.toDataURL('image/png', 1.0)
    link.click()
    ElMessage.success('图片已保存')
  } catch (error) {
    console.error('保存图片失败:', error)
    ElMessage.error('保存失败，请重试')
  } finally {
    isLoading.value = false
  }
}

const handleCopy = async () => {
  const text = `
【玉签阁】
第${toChineseNumber(props.signNumber)}签 [${props.signName}]
${lunarYear.value}${lunarDate.value}

${props.poem}

【解签】${props.interpretation}

来自：玉签阁 ${window.location.href}
  `.trim()
  
  try {
    await navigator.clipboard.writeText(text)
    ElMessage.success('文字已复制')
  } catch (err) {
    console.error('复制失败:', err)
    ElMessage.error('复制失败，请重试')
  }
}

const handleForward = async () => {
  const shareData = {
    title: '玉签阁·求签',
    text: `第${toChineseNumber(props.signNumber)}签 [${props.signName}]\n\n${props.poem}`,
    url: window.location.href
  }

  try {
    if (navigator.canShare && navigator.canShare(shareData)) {
      await navigator.share(shareData)
      ElMessage.success('分享成功')
    } else {
      await navigator.clipboard.writeText(window.location.href)
      ElMessage.success('链接已复制，请手动分享')
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      console.error('分享失败:', err)
      ElMessage.error('分享失败，请重试')
    }
  }
}

const qrCodeValue = computed(() => {
  return window.location.href
})
</script>

<style scoped>
.share-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: var(--spacing-medium);
}

.share-content {
  background: var(--color-jade-white);
  border-radius: 16px;
  padding: var(--spacing-medium);
  max-width: 360px;
  width: 100%;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.1);
}

.share-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--spacing-medium);
}

.share-title {
  font-family: var(--font-family-serif);
  font-size: var(--font-size-lg);
  color: var(--color-accent-gold);
  position: relative;
  padding-left: var(--spacing-medium);
}

.share-title::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 4px;
  height: 70%;
  background: var(--color-accent-gold);
  border-radius: 2px;
  opacity: 0.8;
}

.close-btn {
  background: none;
  border: none;
  padding: var(--spacing-xs);
  cursor: pointer;
  opacity: 0.6;
  transition: opacity 0.3s ease;
}

.close-btn:hover {
  opacity: 1;
}

.close-icon {
  width: 20px;
  height: 20px;
  fill: var(--color-cloud-gray);
}

.card-preview {
  background: var(--color-jade-white);
  border-radius: 8px;
  padding: var(--spacing-medium);
  margin-bottom: var(--spacing-medium);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.header-wrapper {
  position: relative;
  display: flex;
  justify-content: center;
  margin-bottom: var(--spacing-medium);
  min-height: 60px;
}

.sign-info {
  display: flex;
  align-items: center;
  gap: var(--spacing-small);
}

.sign-number {
  font-family: var(--font-family-serif);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-lg);
}

.sign-name {
  font-family: var(--font-family-serif);
  color: var(--color-accent-gold);
  font-size: var(--font-size-lg);
}

.date-wrapper {
  position: absolute;
  right: 0;
  top: 0;
  display: flex;
  gap: var(--spacing-xs);
}

.date-text, .year-text {
  font-family: var(--font-family-serif);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-sm);
  opacity: 0.8;
  writing-mode: vertical-rl;
  text-orientation: upright;
  letter-spacing: 0.2em;
}

.poem-section {
  margin: var(--spacing-medium) 0;
  padding: var(--spacing-medium) var(--spacing-medium);
  position: relative;
  display: flex;
  justify-content: center;
}

.poem-section::before,
.poem-section::after {
  content: '';
  position: absolute;
  width: 1px;
  height: 80%;
  top: 10%;
  background: linear-gradient(to bottom, 
    transparent 0%,
    var(--color-accent-gold) 20%,
    var(--color-accent-gold) 80%,
    transparent 100%
  );
  opacity: 0.3;
}

.poem-section::before {
  left: 0;
}

.poem-section::after {
  right: 0;
}

.poem {
  font-family: var(--font-family-serif);
  color: var(--color-accent-gold);
  text-align: center;
  white-space: pre-line;
  line-height: 2.2;
  font-size: var(--font-size-base);
  position: relative;
  padding: 0 var(--spacing-large);
  max-width: 320px;
  text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.05);
}

.divider {
  height: 1px;
  background: rgba(180, 161, 98, 0.2);
  margin: var(--spacing-medium) 0;
}

.interpretation-section {
  padding: 0 var(--spacing-medium);
}

.interpretation {
  color: var(--color-ink-black);
  opacity: 0.75;
  line-height: 1.8;
  text-align: justify;
  font-size: var(--font-size-sm);
}

.footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: var(--spacing-medium);
  padding-top: var(--spacing-small);
  border-top: 1px solid rgba(180, 161, 98, 0.2);
  padding-right: var(--spacing-small);
}

.qrcode {
  width: 40px;
  height: 40px;
  border-radius: 4px;
  overflow: hidden;
  background: var(--color-jade-white);
  padding: 3px;
  border: 1px solid rgba(180, 161, 98, 0.2);
  opacity: 0.85;
  transition: opacity 0.3s ease;
  margin-left: var(--spacing-medium);
}

.qrcode:hover {
  opacity: 1;
}

.qr-code {
  width: 100%;
  height: 100%;
  filter: drop-shadow(0 1px 1px rgba(0, 0, 0, 0.05));
}

.footer-text {
  font-family: var(--font-family-serif);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-xs);
  opacity: 0.8;
  text-align: left;
}

.share-actions {
  display: flex;
  justify-content: center;
  gap: var(--spacing-medium);
  margin-top: var(--spacing-medium);
}

.action-btn {
  display: flex;
  align-items: center;
  gap: var(--spacing-xs);
  padding: var(--spacing-xs) var(--spacing-medium);
  border: none;
  border-radius: 4px;
  background: none;
  cursor: pointer;
  transition: var(--transition-base);
  color: var(--color-cloud-gray);
}

.action-btn:hover {
  color: var(--color-accent-gold);
}

.action-icon {
  width: 18px;
  height: 18px;
  fill: currentColor;
}

.action-btn span {
  font-family: var(--font-family-serif);
  font-size: var(--font-size-sm);
}

@media (max-width: 480px) {
  .share-content {
    padding: var(--spacing-small);
  }
  
  .card-preview {
    padding: var(--spacing-small);
  }
  
  .poem {
    font-size: var(--font-size-sm);
  }
  
  .interpretation {
    font-size: var(--font-size-xs);
  }
  
  .action-btn {
    padding: var(--spacing-xs) var(--spacing-small);
  }
  
  .action-icon {
    width: 16px;
    height: 16px;
  }
  
  .action-btn span {
    font-size: var(--font-size-xs);
  }
  
  .share-title {
    font-size: var(--font-size-base);
    padding-left: var(--spacing-small);
  }
  
  .share-title::before {
    width: 3px;
  }
  
  .close-icon {
    width: 18px;
    height: 18px;
  }
}
</style> 