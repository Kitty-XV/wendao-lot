<template>
  <div class="resolve-wrapper" v-if="visible">
    <div class="resolve-content">
      <h3 class="resolve-title">化解</h3>
      <p class="resolve-desc">天无绝人之路，心存善念，事必有解</p>
      
      <div class="resolve-steps">
        <div class="step" v-for="(step, index) in steps" :key="index"
             :class="{ 'completed': completedSteps.includes(index) }"
             @click="completeStep(index)">
          <div class="step-icon">
            <svg class="check-icon" v-if="completedSteps.includes(index)" viewBox="0 0 24 24">
              <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
            </svg>
            <span v-else>{{ index + 1 }}</span>
          </div>
          <div class="step-content">
            <h4>{{ step.title }}</h4>
            <p>{{ step.desc }}</p>
          </div>
        </div>
      </div>

      <div class="resolve-result" v-if="isCompleted">
        <p class="result-text">化解完成</p>
        <button class="close-button" @click="handleClose">明白了</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['close'])

const steps = ref([
  {
    title: '静心冥想',
    desc: '闭目凝神，深呼吸三次，让心神平静'
  },
  {
    title: '祈福许愿',
    desc: '默念美好愿望，相信事情会向好的方向发展'
  },
  {
    title: '行善积德',
    desc: '承诺今日行一善事，积累福报'
  }
])

const completedSteps = ref([])

const isCompleted = computed(() => {
  return completedSteps.value.length === steps.value.length
})

const completeStep = (index) => {
  if (!completedSteps.value.includes(index)) {
    completedSteps.value.push(index)
  }
}

const handleClose = () => {
  emit('close')
  completedSteps.value = []
}
</script>

<style scoped>
.resolve-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: var(--spacing-medium);
}

.resolve-content {
  background: var(--color-jade-white);
  border-radius: 16px;
  padding: var(--spacing-large);
  max-width: 480px;
  width: 100%;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.1);
}

.resolve-title {
  font-family: var(--font-family-serif);
  font-size: var(--font-size-xl);
  color: var(--color-ink-black);
  text-align: center;
  margin-bottom: var(--spacing-small);
}

.resolve-desc {
  color: var(--color-cloud-gray);
  text-align: center;
  margin-bottom: var(--spacing-large);
}

.resolve-steps {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-medium);
}

.step {
  display: flex;
  align-items: flex-start;
  gap: var(--spacing-medium);
  padding: var(--spacing-medium);
  border: 1px solid rgba(180, 161, 98, 0.2);
  border-radius: 8px;
  cursor: pointer;
  transition: var(--transition-base);
}

.step:hover {
  background: rgba(180, 161, 98, 0.05);
}

.step.completed {
  background: rgba(180, 161, 98, 0.1);
  border-color: rgba(180, 161, 98, 0.3);
}

.step-icon {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: var(--color-accent-gold);
  color: var(--color-jade-white);
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-family-serif);
  flex-shrink: 0;
}

.check-icon {
  width: 20px;
  height: 20px;
  fill: currentColor;
}

.step-content h4 {
  font-family: var(--font-family-serif);
  color: var(--color-ink-black);
  margin-bottom: var(--spacing-xs);
}

.step-content p {
  color: var(--color-cloud-gray);
  font-size: var(--font-size-sm);
}

.resolve-result {
  margin-top: var(--spacing-large);
  text-align: center;
}

.result-text {
  color: var(--color-accent-gold);
  font-family: var(--font-family-serif);
  margin-bottom: var(--spacing-medium);
}

.close-button {
  background: var(--color-accent-gold);
  color: var(--color-jade-white);
  border: none;
  padding: var(--spacing-small) var(--spacing-large);
  border-radius: 24px;
  font-family: var(--font-family-serif);
  cursor: pointer;
  transition: var(--transition-base);
}

.close-button:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}
</style> 