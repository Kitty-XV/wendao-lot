<template>
  <div class="app-layout">
    <nav class="navbar">
      <div class="navbar-container">
        <router-link to="/" class="logo">
          <svg width="40" height="40" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="logo-svg">
            <!-- 外圆 -->
            <circle cx="50" cy="50" r="48" stroke="var(--color-ink-black)" stroke-width="2"/>
            <!-- 内圆 -->
            <circle cx="50" cy="50" r="42" stroke="var(--color-ink-black)" stroke-width="1" stroke-opacity="0.6"/>
            <!-- 阁楼 -->
            <!-- 顶部宝珠 -->
            <circle cx="50" cy="20" r="2" fill="var(--color-ink-black)"/>
            <!-- 主屋顶 - 上层飞檐 -->
            <path d="M30,42 C35,38 45,35 50,35 C55,35 65,38 70,42 C65,40 55,38 50,38 C45,38 35,40 30,42 Z" 
                  stroke="var(--color-ink-black)" 
                  stroke-width="1.5"
                  fill="none"/>
            <!-- 主屋顶 -->
            <path d="M25,45 C35,40 45,38 50,38 C55,38 65,40 75,45" 
                  stroke="var(--color-ink-black)" 
                  stroke-width="2.5" 
                  stroke-linecap="round"
                  fill="none"/>
            <!-- 二层屋檐 -->
            <path d="M32,52 C40,50 45,49 50,49 C55,49 60,50 68,52" 
                  stroke="var(--color-ink-black)" 
                  stroke-width="2" 
                  stroke-linecap="round"/>
            <!-- 主体结构 - 立柱 -->
            <path d="M38,52 L38,75 M62,52 L62,75" 
                  stroke="var(--color-ink-black)" 
                  stroke-width="2"/>
            <!-- 窗格 -->
            <path d="M44,58 L56,58 M44,65 L56,65" 
                  stroke="var(--color-ink-black)" 
                  stroke-width="1.5"/>
            <!-- 底座 -->
            <path d="M35,75 C40,73 45,72 50,72 C55,72 60,73 65,75" 
                  stroke="var(--color-ink-black)" 
                  stroke-width="3" 
                  stroke-linecap="round"/>
          </svg>
        </router-link>
        <div class="nav-links">
          <router-link to="/" class="nav-link">首页</router-link>
          <router-link to="/history" class="nav-link">历史</router-link>
        </div>
      </div>
    </nav>
    
    <main class="main-container">
      <slot></slot>
    </main>

    <MobileNav />
  </div>
</template>

<script setup>
import MobileNav from './MobileNav.vue'
</script>

<style scoped>
.app-layout {
  min-height: 100vh;
  background: var(--color-jade-white);
}

.navbar-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--page-padding);
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo {
  display: flex;
  align-items: center;
  text-decoration: none;
  padding: 8px;
}

.logo-svg {
  transition: transform 0.3s ease;
}

.logo:hover .logo-svg {
  transform: scale(1.05);
}

.nav-links {
  display: flex;
  gap: var(--spacing-large);
}

.nav-link {
  color: var(--color-cloud-gray);
  text-decoration: none;
  font-size: var(--font-size-base);
  transition: var(--transition-base);
}

.nav-link:hover,
.nav-link.router-link-active {
  color: var(--color-ink-black);
}

.main-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: calc(64px + var(--spacing-large)) var(--page-padding) var(--spacing-large);
}

@media (max-width: 767px) {
  .nav-links {
    display: none;
  }
  
  .main-container {
    padding-bottom: calc(64px + var(--spacing-large));
  }
}
</style> 