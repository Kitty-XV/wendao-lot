<template>
  <router-view v-slot="{ Component }">
    <transition name="fade" mode="out-in">
      <component :is="Component" />
    </transition>
  </router-view>
</template>

<script setup>
// App level logic
</script>

<style>
@import './styles/variables.css';
@import './styles/components.css';

/* 全局样式 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: var(--font-family-serif);
  font-size: var(--font-size-base);
  line-height: 1.5;
  color: var(--color-ink-black);
  background: var(--color-jade-white);
}

/* 页面过渡动画 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* 滚动条样式 */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: rgba(163, 191, 191, 0.1);
}

::-webkit-scrollbar-thumb {
  background: var(--color-cloud-gray);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: var(--color-accent-gold);
}
</style> 