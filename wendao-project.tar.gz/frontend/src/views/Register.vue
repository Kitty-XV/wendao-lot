<template>
  <Layout>
    <div class="register-container">
      <h2 class="register-title">注册玉签斋</h2>
      <form @submit.prevent="handleRegister" class="register-form">
        <div class="form-group">
          <input 
            type="text" 
            v-model="form.username" 
            placeholder="用户名"
            class="input"
            required
            :class="{ 'error': errors.username }"
            @input="clearError('username')"
            minlength="3"
            maxlength="20"
          />
          <span v-if="errors.username" class="error-message">{{ errors.username }}</span>
        </div>
        <div class="form-group">
          <input 
            type="password" 
            v-model="form.password" 
            placeholder="密码"
            class="input"
            required
            :class="{ 'error': errors.password }"
            @input="clearError('password')"
            minlength="6"
          />
          <span v-if="errors.password" class="error-message">{{ errors.password }}</span>
        </div>
        <div class="form-group">
          <input 
            type="password" 
            v-model="form.confirmPassword" 
            placeholder="确认密码"
            class="input"
            required
            :class="{ 'error': errors.confirmPassword }"
            @input="clearError('confirmPassword')"
          />
          <span v-if="errors.confirmPassword" class="error-message">{{ errors.confirmPassword }}</span>
        </div>
        <button 
          type="submit" 
          class="register-btn"
          :disabled="isLoading"
        >
          <span v-if="isLoading" class="loading-spinner"></span>
          <span v-else>注 册</span>
        </button>
      </form>
      <p class="login-hint">
        已有账号？
        <router-link to="/profile" class="login-link">立即登录</router-link>
      </p>
    </div>
  </Layout>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import Layout from '../components/Layout.vue'
import { userService } from '../services/userService'

const router = useRouter()
const isLoading = ref(false)
const form = ref({
  username: '',
  password: '',
  confirmPassword: ''
})

const errors = ref({
  username: '',
  password: '',
  confirmPassword: ''
})

const clearError = (field) => {
  errors.value[field] = ''
}

const validateForm = () => {
  let isValid = true
  errors.value = {
    username: '',
    password: '',
    confirmPassword: ''
  }

  // 用户名验证
  if (!form.value.username) {
    errors.value.username = '请输入用户名'
    isValid = false
  } else if (form.value.username.length < 3) {
    errors.value.username = '用户名至少需要3个字符'
    isValid = false
  }

  // 密码验证
  if (!form.value.password) {
    errors.value.password = '请输入密码'
    isValid = false
  } else if (form.value.password.length < 6) {
    errors.value.password = '密码至少需要6个字符'
    isValid = false
  }

  // 确认密码验证
  if (!form.value.confirmPassword) {
    errors.value.confirmPassword = '请确认密码'
    isValid = false
  } else if (form.value.password !== form.value.confirmPassword) {
    errors.value.confirmPassword = '两次输入的密码不一致'
    isValid = false
  }

  return isValid
}

const handleRegister = async () => {
  if (!validateForm()) return

  try {
    isLoading.value = true
    await userService.register(form.value.username, form.value.password)
    // 注册成功后自动登录
    const loginResult = await userService.login(form.value.username, form.value.password)
    localStorage.setItem('token', loginResult.token)
    router.push('/profile')
  } catch (error) {
    console.error('注册失败:', error)
    if (error.response?.data?.message === '用户名已存在') {
      errors.value.username = '该用户名已被注册'
    } else {
      errors.value.username = error.response?.data?.message || '注册失败，请稍后重试'
    }
  } finally {
    isLoading.value = false
  }
}
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 0 auto;
  padding: var(--spacing-large);
}

.register-title {
  font-family: var(--font-family-serif);
  font-size: var(--font-size-xl);
  color: var(--color-ink-black);
  text-align: center;
  margin-bottom: var(--spacing-large);
  letter-spacing: 0.1em;
}

.register-form {
  background: var(--color-jade-white);
  padding: var(--spacing-large);
  border-radius: var(--radius-large);
  box-shadow: var(--shadow-card);
  border: 1px solid rgba(180, 161, 98, 0.1);
  margin-bottom: var(--spacing-medium);
  transition: box-shadow 0.3s ease;
}

.register-form:hover {
  box-shadow: var(--shadow-float);
}

.form-group {
  margin-bottom: var(--spacing-medium);
  position: relative;
}

.input {
  width: 100%;
  height: 48px;
  background: rgba(243, 247, 247, 0.5);
  border: 1px solid rgba(180, 161, 98, 0.2);
  border-radius: var(--radius-medium);
  padding: 0 var(--spacing-medium);
  font-size: var(--font-size-base);
  color: var(--color-ink-black);
  transition: var(--transition-base);
  font-family: var(--font-family-sans);
  margin-bottom: 0;
}

.input:focus {
  border-color: var(--color-accent-gold);
  box-shadow: 0 0 0 3px rgba(180, 161, 98, 0.1);
  outline: none;
}

.input::placeholder {
  color: var(--color-cloud-gray);
}

.register-btn {
  width: 100%;
  height: 48px;
  background: var(--color-accent-gold);
  color: white;
  border: none;
  border-radius: var(--radius-medium);
  font-size: var(--font-size-base);
  cursor: pointer;
  transition: var(--transition-smooth);
  letter-spacing: 0.1em;
  font-family: var(--font-family-serif);
  margin-top: var(--spacing-medium);
}

.register-btn:hover {
  background: #a3904b;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(180, 161, 98, 0.2);
}

.register-btn:active {
  transform: translateY(0);
  box-shadow: none;
}

.login-hint {
  text-align: center;
  margin-top: var(--spacing-medium);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-sm);
  font-family: var(--font-family-sans);
}

.login-link {
  color: var(--color-accent-gold);
  text-decoration: none;
  transition: var(--transition-base);
  margin-left: var(--spacing-small);
  font-family: var(--font-family-serif);
}

.login-link:hover {
  color: #a3904b;
  text-decoration: underline;
}

/* 响应式设计 */
@media (max-width: 640px) {
  .register-container {
    padding: var(--spacing-medium);
  }

  .register-form {
    padding: var(--spacing-medium);
  }

  .register-title {
    font-size: var(--font-size-lg);
  }

  .input {
    height: 44px;
  }

  .register-btn {
    height: 44px;
  }

  .error-message {
    font-size: calc(var(--font-size-sm) - 1px);
  }
}

/* 表单验证样式 */
.input:invalid {
  border-color: var(--color-cinnabar-red);
}

.input:invalid:focus {
  border-color: var(--color-cinnabar-red);
  box-shadow: 0 0 0 3px rgba(209, 75, 75, 0.1);
}

/* 加载状态样式 */
.register-btn:disabled {
  background: var(--color-cloud-gray);
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

/* 错误状态样式 */
.input.error {
  border-color: var(--color-cinnabar-red);
}

.input.error:focus {
  border-color: var(--color-cinnabar-red);
  box-shadow: 0 0 0 3px rgba(209, 75, 75, 0.1);
}

.error-message {
  display: block;
  color: var(--color-cinnabar-red);
  font-size: var(--font-size-sm);
  margin-top: 4px;
  font-family: var(--font-family-sans);
}

/* 加载状态样式 */
.loading-spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 0.8s linear infinite;
  margin: 0 auto;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
</style> 