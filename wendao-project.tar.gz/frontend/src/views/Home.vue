<template>
  <Layout>
    <div class="home">
      <div class="cloud-bg"></div>
      
      <div class="lunar-date">
        <div class="date-container">
          <div class="date-decoration top"></div>
          <div class="date-content">
            {{ getTodayLunarDate() }}
          </div>
          <div class="date-decoration bottom"></div>
        </div>
      </div>
      
      <div class="content-wrapper">
        <div class="header-section">
          <h1 class="title">问道阁</h1>
          <p class="subtitle">玉签问道，心诚则灵</p>
        </div>
        
        <div class="draw-section">
          <div class="draw-container">
            <div class="draw-decoration">
              <div class="circle"></div>
              <div class="line"></div>
            </div>
            <button 
              class="draw-button"
              :class="{ 'disabled': isDrawDisabled, 'loading': isLoading }"
              @click="handleDraw"
              :disabled="isLoading"
            >
              <div class="button-content">
                <span class="draw-text" v-if="!isLoading">求签</span>
                <span class="loading-text" v-else>
                  <span class="dot">●</span>
                  <span class="dot">●</span>
                  <span class="dot">●</span>
                </span>
              </div>
            </button>
          </div>
          
          <transition name="fade">
            <p class="draw-message" v-if="false">
              {{ getTodayLunarDate() }}
            </p>
          </transition>
        </div>
        
        <div class="footer-section">
          <div class="quote-box">
            <p class="quote">{{ dailyQuote.text }}</p>
          </div>
        </div>
      </div>
    </div>
  </Layout>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import Layout from '../components/Layout.vue'
import { Lunar } from 'lunar-javascript'
import { ElMessage } from 'element-plus'
import signService from '../services/signService'
import { useSignStore } from '../store/sign'

const router = useRouter()
const signStore = useSignStore()
const isDrawDisabled = computed(() => signStore.hasDrawnToday)
const isLoading = ref(false)

const dailyQuote = ref({
  text: '一炷心香寄虔诚\n静待天机慢慢明\n签文解语皆随缘\n万事由心莫强求'
})

const handleDraw = async () => {
  if (isDrawDisabled.value) {
    ElMessage({
      message: '今日已求签，请明日再来',
      type: 'warning',
      duration: 3000,
      customClass: 'custom-message',
      offset: 50,
      center: true,
      grouping: true,
      showClose: false
    })
    return;
  }

  isLoading.value = true;
  try {
    const result = await signService.getTodaySign();
    
    if (result) {
      signStore.setCurrentSign(result);
      router.push('/result');
    }
  } catch (error) {
    console.error('求签失败:', error);
    if (error.message === '网络连接失败') {
      ElMessage.error('网络连接失败，请检查网络后重试');
    } else {
      ElMessage.error(error.message || '获取签文失败，请稍后重试');
    }
  } finally {
    isLoading.value = false;
  }
};

const getTodayLunarDate = () => {
  const lunar = Lunar.fromDate(new Date())
  return `${lunar.getYearInGanZhi()}年${lunar.getMonthInChinese()}月${lunar.getDayInChinese()}`
}

onMounted(async () => {
  // 初始化完成
});
</script>

<style>
/* 自定义消息提示样式 */
.custom-message {
  padding: 12px 24px !important;
  min-width: 320px !important;
  border: none !important;
  border-radius: 4px !important;
  background: rgba(243, 247, 247, 0.95) !important;
  backdrop-filter: blur(12px) !important;
  box-shadow: 
    0 4px 16px rgba(74, 99, 99, 0.08),
    0 0 1px rgba(74, 99, 99, 0.12) !important;
}

.custom-message .el-message__content {
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif !important;
  font-size: 1.1rem !important;
  letter-spacing: 0.1em !important;
  color: #4A6363 !important;
  line-height: 1.5 !important;
  text-align: center !important;
}

/* 移除 Element Plus 默认的图标 */
.custom-message .el-message__icon {
  display: none !important;
}

/* 添加自定义边框装饰 */
.custom-message::before,
.custom-message::after {
  content: '';
  position: absolute;
  height: 1px;
  width: 60px;
  background: linear-gradient(90deg, transparent, rgba(74, 99, 99, 0.2), transparent);
}

.custom-message::before {
  top: 0;
  left: 50%;
  transform: translateX(-50%);
}

.custom-message::after {
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
}

@media (max-width: 767px) {
  .custom-message {
    min-width: 280px !important;
    margin: 0 20px !important;
  }
  
  .custom-message .el-message__content {
    font-size: 1rem !important;
  }
}
</style>

<style scoped>
.home {
  position: relative;
  min-height: calc(100vh - 64px);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.cloud-bg {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: url("data:image/svg+xml,%3Csvg width='400' height='400' viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M50,200 C100,100 200,150 300,200 S400,300 450,250' fill='none' stroke='%23B4A162' stroke-width='0.5' opacity='0.3'/%3E%3Cpath d='M0,150 C150,50 250,250 400,150' fill='none' stroke='%23B4A162' stroke-width='0.5' opacity='0.3'/%3E%3Cpath d='M-50,100 C100,200 200,50 350,150' fill='none' stroke='%23B4A162' stroke-width='0.5' opacity='0.3'/%3E%3Cpath d='M0,300 C150,200 250,400 400,300' fill='none' stroke='%23B4A162' stroke-width='0.5' opacity='0.3'/%3E%3Cpath d='M100,0 C200,100 300,50 400,100' fill='none' stroke='%23B4A162' stroke-width='0.5' opacity='0.3'/%3E%3Cpath d='M50,350 C150,250 250,300 350,250' fill='none' stroke='%23B4A162' stroke-width='0.5' opacity='0.3'/%3E%3C/svg%3E");
  background-repeat: repeat;
  opacity: 0.55;
  background-size: 400px 400px;
  background-color: transparent;
}

.content-wrapper {
  text-align: center;
  z-index: 1;
  padding: var(--spacing-large);
  max-width: 600px;
  width: 100%;
}

.header-section {
  margin-bottom: var(--spacing-large);
  text-align: center;
}

.title {
  font-family: var(--font-family-serif);
  font-size: 48px;
  color: var(--color-ink-black);
  margin-bottom: var(--spacing-medium);
  letter-spacing: 0.1em;
  position: relative;
  display: inline-block;
  padding: 0 var(--spacing-large);
}

.title::before,
.title::after {
  content: '';
  position: absolute;
  top: 50%;
  width: var(--spacing-medium);
  height: 1px;
  background: var(--color-accent-gold);
  opacity: 0.3;
}

.title::before {
  right: 100%;
}

.title::after {
  left: 100%;
}

.subtitle {
  font-size: var(--font-size-lg);
  color: var(--color-cloud-gray);
  margin-bottom: var(--spacing-large);
  letter-spacing: 0.05em;
}

.draw-section {
  margin: var(--spacing-large) 0;
  position: relative;
}

.draw-container {
  position: relative;
  display: inline-block;
}

.draw-decoration {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 160px;
  height: 160px;
  border: 1px solid rgba(180, 161, 98, 0.2);
  border-radius: 50%;
  pointer-events: none;
}

.draw-decoration::before {
  content: '';
  position: absolute;
  top: -10px;
  left: -10px;
  right: -10px;
  bottom: -10px;
  border: 1px solid rgba(180, 161, 98, 0.1);
  border-radius: 50%;
}

.draw-button {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: rgba(243, 247, 247, 0.85);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(180, 161, 98, 0.3);
  cursor: pointer;
  transition: var(--transition-smooth);
  position: relative;
  overflow: hidden;
}

.draw-button::before {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(
    circle at center,
    rgba(180, 161, 98, 0.1) 0%,
    transparent 70%
  );
  animation: rotate 10s linear infinite;
}

.button-content {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.draw-text {
  font-family: var(--font-family-serif);
  font-size: var(--font-size-xl);
  color: var(--color-ink-black);
  margin-bottom: 4px;
}

.draw-hint {
  font-size: var(--font-size-xs);
  color: var(--color-cloud-gray);
}

.draw-button:hover {
  transform: scale(1.05);
  box-shadow: 0 0 30px rgba(180, 161, 98, 0.2);
}

.draw-button.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.draw-message {
  margin-top: var(--spacing-medium);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-sm);
  letter-spacing: 0.05em;
}

.footer-section {
  margin-top: calc(var(--spacing-large) * 2);
}

.quote-box {
  padding: var(--spacing-medium);
  border-top: 1px solid rgba(180, 161, 98, 0.1);
  border-bottom: 1px solid rgba(180, 161, 98, 0.1);
}

.quote {
  white-space: pre-line;
  line-height: 1.8;
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif;
  color: var(--color-cloud-gray);
  font-size: 0.85rem;
  letter-spacing: 0.06em;
  opacity: 0.9;
}

.quote-author {
  font-size: var(--font-size-sm);
  color: var(--color-accent-gold);
}

@keyframes cloudFloat {
  from { transform: translate(0, 0); }
  to { transform: translate(-50%, -50%); }
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@media (max-width: 767px) {
  .title {
    font-size: 36px;
  }
  
  .subtitle {
    font-size: var(--font-size-base);
  }
  
  .draw-button {
    width: 100px;
    height: 100px;
  }
  
  .draw-decoration {
    width: 140px;
    height: 140px;
  }
  
  .draw-text {
    font-size: var(--font-size-lg);
  }
  
  .content-wrapper {
    padding: var(--spacing-medium);
  }
  
  .quote {
    font-size: 0.8rem;
    line-height: 1.7;
    letter-spacing: 0.05em;
  }
}

.lunar-date {
  position: fixed;
  right: 2rem;
  top: 35%;
  transform: translateY(-50%);
  z-index: 2;
  writing-mode: vertical-lr;
  text-orientation: upright;
}

.date-container {
  background: rgba(243, 247, 247, 0.9);
  backdrop-filter: blur(8px);
  padding: 1.5rem 0.8rem;
  border-radius: 2px;
  position: relative;
  box-shadow: 
    0 2px 12px rgba(74, 99, 99, 0.06),
    0 0 1px rgba(74, 99, 99, 0.1);
}

.date-content {
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif;
  font-size: 0.9rem;
  color: #4A6363;
  letter-spacing: 0.2em;
  line-height: 1.8;
  position: relative;
  padding: 0.5rem 0;
}

.date-decoration {
  position: absolute;
  left: 50%;
  width: 1px;
  height: 40px;
  background: linear-gradient(to bottom, 
    transparent,
    rgba(180, 161, 98, 0.3) 20%,
    rgba(180, 161, 98, 0.3) 80%,
    transparent
  );
}

.date-decoration.top {
  top: -30px;
}

.date-decoration.top::before,
.date-decoration.bottom::before {
  content: '';
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: rgba(180, 161, 98, 0.4);
}

.date-decoration.top::before {
  bottom: 0;
}

.date-decoration.bottom {
  bottom: -30px;
}

.date-decoration.bottom::before {
  top: 0;
}

@media (max-width: 767px) {
  .lunar-date {
    right: 1rem;
    top: 30%;
  }
  
  .date-container {
    padding: 1.2rem 0.6rem;
  }
  
  .date-content {
    font-size: 0.85rem;
  }
  
  .date-decoration {
    height: 30px;
  }
  
  .date-decoration.top {
    top: -20px;
  }
  
  .date-decoration.bottom {
    bottom: -20px;
  }
}

.loading-text {
  display: flex;
  gap: 4px;
  align-items: center;
  justify-content: center;
}

.dot {
  font-size: 8px;
  color: var(--color-ink-black);
  opacity: 0.6;
  animation: dotFade 1.4s infinite;
}

.dot:nth-child(2) {
  animation-delay: 0.2s;
}

.dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes dotFade {
  0%, 100% { opacity: 0.2; transform: scale(0.8); }
  50% { opacity: 0.8; transform: scale(1.2); }
}

.draw-button.loading {
  cursor: wait;
  opacity: 0.8;
}

.draw-button.loading::before {
  animation: rotate 1.5s linear infinite;
  opacity: 0.2;
}
</style> 