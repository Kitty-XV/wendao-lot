<template>
  <Layout>
    <div class="history-container">
      <div class="history-page">
        <div class="title-section">
          <h1 class="page-title">签文录</h1>
          <div class="title-decoration"></div>
        </div>
        
        <div class="history-timeline">
          <div class="timeline-line"></div>
          
          <div 
            v-for="record in historyRecords" 
            :key="record.date"
            class="history-item"
            @click="viewDetail(record)"
          >
            <div class="timeline-node">
              <div class="timeline-dot" :class="record.sign.level"></div>
            </div>
            
            <div class="history-card" :class="record.sign.level">
              <div class="history-date">{{ formatDate(record.date) }}</div>
              <div class="history-content">
                <div class="sign-info">
                  <span class="sign-number">第{{ toChineseNumber(record.sign.id) }}签</span>
                  <span class="sign-name">{{ record.sign.name }}</span>
                  <span class="sign-level" :class="record.sign.level">
                    {{ record.sign.level }}签
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div v-if="loading" class="loading-more">
            <div class="loading-spinner"></div>
          </div>

          <div v-if="!loading && historyRecords.length === 0" class="empty-state">
            暂无抽签记录
          </div>
        </div>

        <div v-if="pagination.total > 0" class="pagination">
          <button 
            :disabled="pagination.page === 1"
            @click="changePage(pagination.page - 1)"
            class="page-btn prev"
          >
            上一页
          </button>
          
          <span class="page-info">
            {{ pagination.page }} / {{ pagination.totalPages }}
          </span>
          
          <button 
            :disabled="pagination.page === pagination.totalPages"
            @click="changePage(pagination.page + 1)"
            class="page-btn next"
          >
            下一页
          </button>
        </div>
      </div>
    </div>
  </Layout>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import Layout from '../components/Layout.vue'
import { useSignStore } from '../store/sign'

const router = useRouter()
const signStore = useSignStore()
const loading = ref(false)
const historyRecords = ref([])
const pagination = ref({
  page: 1,
  pageSize: 10,
  total: 0,
  totalPages: 1
})

const loadHistory = async () => {
  loading.value = true
  try {
    const result = signStore.getHistory({
      page: pagination.value.page,
      pageSize: pagination.value.pageSize
    })
    historyRecords.value = result.records
    pagination.value = result.pagination
  } catch (error) {
    console.error('获取历史记录失败:', error)
  } finally {
    loading.value = false
  }
}

const changePage = (newPage) => {
  pagination.value.page = newPage
  loadHistory()
}

const viewDetail = (record) => {
  signStore.setCurrentSign(record.sign)
  router.push('/result')
}

const formatDate = (dateString) => {
  const date = new Date(dateString)
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`
}

const toChineseNumber = (num) => {
  const chineseNumbers = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
  if (num <= 10) return chineseNumbers[num]
  if (num < 20) return '十' + (num % 10 === 0 ? '' : chineseNumbers[num % 10])
  const tens = Math.floor(num / 10)
  return chineseNumbers[tens] + '十' + (num % 10 === 0 ? '' : chineseNumbers[num % 10])
}

onMounted(() => {
  loadHistory()
})
</script>

<style scoped>
.history-container {
  padding: 2rem;
  max-width: 800px;
  margin: 0 auto;
  min-height: calc(100vh - 4rem);
}

.title-section {
  text-align: center;
  margin-bottom: 3rem;
  position: relative;
}

.page-title {
  font-family: "华文行楷", "楷体", "楷体_GB2312", STKaiti, serif;
  font-size: 2.8rem;
  color: #2c3e50;
  margin-bottom: 1.2rem;
  position: relative;
  display: inline-block;
  letter-spacing: 0.3em;
  text-shadow: 2px 2px 4px rgba(180, 161, 98, 0.1);
}

.title-decoration {
  width: 150px;
  height: 2px;
  background: linear-gradient(90deg, transparent, #b4a162, transparent);
  margin: 0 auto;
  position: relative;
}

.title-decoration::before,
.title-decoration::after {
  content: '✦';
  position: absolute;
  top: -12px;
  color: #b4a162;
  font-size: 1rem;
  opacity: 0.6;
}

.title-decoration::before {
  left: 25%;
}

.title-decoration::after {
  right: 25%;
}

.history-timeline {
  position: relative;
  padding: 2rem 0;
}

.timeline-line {
  position: absolute;
  left: 20px;
  top: 0;
  bottom: 0;
  width: 1px;
  background: linear-gradient(180deg, 
    rgba(180, 161, 98, 0.8) 0%,
    rgba(180, 161, 98, 0.2) 100%
  );
}

.history-item {
  position: relative;
  margin-bottom: 2rem;
  padding-left: 3rem;
  display: flex;
  align-items: flex-start;
}

.timeline-node {
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
}

.timeline-dot {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: 2px solid #fff;
  box-shadow: 0 0 0 2px rgba(180, 161, 98, 0.3);
  transition: all 0.3s ease;
}

.history-item:hover .timeline-dot {
  transform: scale(1.2);
  box-shadow: 0 0 0 4px rgba(180, 161, 98, 0.2);
}

.timeline-dot.上上 { background: #E6B422; }
.timeline-dot.上 { background: #C89932; }
.timeline-dot.中 { background: #8E7437; }
.timeline-dot.下 { background: #6C4C1C; }
.timeline-dot.下下 { background: #583C12; }

.history-card {
  flex: 1;
  background: #fcfaf7;
  border-radius: 12px;
  padding: 1.2rem 2rem;
  box-shadow: 
    0 2px 12px rgba(180, 161, 98, 0.08),
    0 0 1px rgba(180, 161, 98, 0.2);
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
  overflow: hidden;
  border: none;
  cursor: pointer;
}

.history-card::before {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 35%;
  height: 100%;
  opacity: 0.08;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  background: linear-gradient(105deg, transparent, rgba(180, 161, 98, 0.08));
}

.history-card::after {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 35%;
  height: 100%;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

/* 上上签：金色渐变 */
.history-card.上上::after {
  background: linear-gradient(105deg, 
    transparent,
    rgba(230, 180, 34, 0.02) 15%,
    rgba(230, 180, 34, 0.04) 30%,
    rgba(230, 180, 34, 0.08) 45%,
    rgba(230, 180, 34, 0.12) 60%,
    rgba(230, 180, 34, 0.16) 75%,
    rgba(230, 180, 34, 0.2) 90%,
    rgba(230, 180, 34, 0.25)
  );
}

/* 上签：浅金渐变 */
.history-card.上::after {
  background: linear-gradient(105deg, 
    transparent,
    rgba(200, 153, 50, 0.02) 15%,
    rgba(200, 153, 50, 0.04) 30%,
    rgba(200, 153, 50, 0.08) 45%,
    rgba(200, 153, 50, 0.12) 60%,
    rgba(200, 153, 50, 0.16) 75%,
    rgba(200, 153, 50, 0.2) 90%,
    rgba(200, 153, 50, 0.25)
  );
}

/* 中签：青铜渐变 */
.history-card.中::after {
  background: linear-gradient(105deg, 
    transparent,
    rgba(142, 116, 55, 0.02) 15%,
    rgba(142, 116, 55, 0.04) 30%,
    rgba(142, 116, 55, 0.08) 45%,
    rgba(142, 116, 55, 0.12) 60%,
    rgba(142, 116, 55, 0.16) 75%,
    rgba(142, 116, 55, 0.2) 90%,
    rgba(142, 116, 55, 0.25)
  );
}

/* 下签：深褐渐变 */
.history-card.下::after {
  background: linear-gradient(105deg, 
    transparent,
    rgba(108, 76, 28, 0.02) 15%,
    rgba(108, 76, 28, 0.04) 30%,
    rgba(108, 76, 28, 0.08) 45%,
    rgba(108, 76, 28, 0.12) 60%,
    rgba(108, 76, 28, 0.16) 75%,
    rgba(108, 76, 28, 0.2) 90%,
    rgba(108, 76, 28, 0.25)
  );
}

/* 下下签：墨色渐变 */
.history-card.下下::after {
  background: linear-gradient(105deg, 
    transparent,
    rgba(88, 60, 18, 0.02) 15%,
    rgba(88, 60, 18, 0.04) 30%,
    rgba(88, 60, 18, 0.08) 45%,
    rgba(88, 60, 18, 0.12) 60%,
    rgba(88, 60, 18, 0.16) 75%,
    rgba(88, 60, 18, 0.2) 90%,
    rgba(88, 60, 18, 0.25)
  );
}

.history-card:hover {
  transform: translateX(5px);
  box-shadow: 
    0 4px 20px rgba(180, 161, 98, 0.12),
    0 0 2px rgba(180, 161, 98, 0.25);
}

.history-card:hover::before {
  opacity: 0.12;
  width: 38%;
}

.history-card:hover::after {
  width: 38%;
}

.history-content {
  position: relative;
  z-index: 1;
}

.sign-info {
  display: flex;
  align-items: center;
  gap: 1.2rem;
  flex-wrap: wrap;
}

.sign-number {
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif;
  font-size: 1.25rem;
  color: #2c3e50;
  letter-spacing: 0.1em;
}

.sign-name {
  font-family: "华文仿宋", "仿宋", "仿宋_GB2312", FangSong, serif;
  font-size: 1.25rem;
  color: #2c3e50;
  letter-spacing: 0.05em;
  position: relative;
  padding-left: 1.2rem;
}

.sign-name::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: #b4a162;
  opacity: 0.6;
}

.sign-level {
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif;
  padding: 3px 12px;
  border-radius: 4px;
  font-size: 0.9rem;
  color: #fff;
  letter-spacing: 0.1em;
  opacity: 0.9;
}

.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
}

.page-btn {
  font-family: "华文楷体", "楷体", "楷体_GB2312", STKaiti, serif;
  padding: 0.5rem 1.2rem;
  border: 1px solid rgba(180, 161, 98, 0.3);
  border-radius: 4px;
  background: #fff;
  color: #2c3e50;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.3s ease;
  letter-spacing: 0.1em;
}

.page-btn:hover:not(:disabled) {
  background: rgba(180, 161, 98, 0.05);
  border-color: #b4a162;
}

.page-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.page-info {
  font-family: "华文仿宋", "仿宋", "仿宋_GB2312", FangSong, serif;
  color: #666;
  font-size: 0.95rem;
  letter-spacing: 0.05em;
}

.empty-state {
  text-align: center;
  padding: 3rem;
  color: #666;
  font-family: "华文仿宋", "仿宋", "仿宋_GB2312", FangSong, serif;
  font-size: 1.1rem;
  letter-spacing: 0.1em;
}

@media (max-width: 767px) {
  .history-container {
    padding: 1rem;
  }
  
  .page-title {
    font-size: 2.2rem;
  }
  
  .history-item {
    padding-left: 2.5rem;
  }
  
  .timeline-line {
    left: 15px;
  }
  
  .timeline-node {
    left: 8px;
  }
  
  .history-card {
    padding: 1rem 1.5rem;
  }
  
  .history-card::before,
  .history-card::after {
    width: 40%;
  }
  
  .history-card:hover::before,
  .history-card:hover::after {
    width: 45%;
  }
  
  .sign-info {
    gap: 0.8rem;
  }
  
  .sign-name {
    padding-left: 0.8rem;
  }
  
  .sign-number,
  .sign-name {
    font-size: 1.1rem;
  }
}
</style> 