<template>
  <Layout>
    <div v-if="!error" class="result">
      <div class="result-content">
        <div class="header-wrapper">
          <div class="sign-info">
            <span class="sign-number">第{{ toChineseNumber(signNumber) }}签</span>
            <span class="sign-name">[{{ signName }}]</span>
          </div>
          <div class="date-wrapper">
            <div class="date-text">{{ lunarDate }}</div>
            <div class="year-text">{{ lunarYear }}</div>
          </div>
        </div>
        
        <div class="poem-section">
          <p class="poem">{{ poem }}</p>
        </div>
        
        <div class="divider"></div>
        
        <div class="interpretation-section">
          <p class="explanation">【解签】{{ explanation }}</p>
        </div>
        
        <div class="actions">
          <button class="share-btn" @click="showShare = true">分享</button>
          <button class="history-btn" @click="router.push('/history')">历史</button>
        </div>
      </div>
    </div>
    
    <div v-else-if="error" class="error">
      <p>{{ error }}</p>
      <button @click="fetchTodaySign">重试</button>
    </div>
    
    <ShareCard
      v-if="showShare"
      :visible="showShare"
      :sign-number="signNumber"
      :sign-name="signName"
      :poem="poem"
      :interpretation="interpretation"
      @close="handleShareClose"
    />
  </Layout>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import Layout from '../components/Layout.vue'
import ShareCard from '../components/ShareCard.vue'
import { Lunar } from 'lunar-javascript'
import signService from '../services/signService'
import { useRouter } from 'vue-router'

const router = useRouter()
const error = ref(null)

// 签文数据
const signNumber = ref(null)
const signName = ref('')
const poem = ref('')
const explanation = ref('')
const interpretation = ref('')

const showShare = ref(false)

// 获取今日签文
const fetchTodaySign = async () => {
  try {
    const sign = await signService.getTodaySign()
    signNumber.value = sign.id
    signName.value = sign.name
    poem.value = sign.poem
    explanation.value = sign.explanation
    interpretation.value = sign.interpretation
  } catch (err) {
    error.value = '获取签文失败，请稍后重试'
    console.error('获取签文失败:', err)
  }
}

onMounted(() => {
  fetchTodaySign()
})

const lunarYear = computed(() => {
  const lunar = Lunar.fromDate(new Date())
  return `${lunar.getYearInGanZhi()}年`
})

const lunarDate = computed(() => {
  const lunar = Lunar.fromDate(new Date())
  return `${lunar.getMonthInChinese()}月${lunar.getDayInChinese()}`
})

const toChineseNumber = (num) => {
  if (num === null || num === undefined) return '';
  
  const chineseNumbers = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
  const number = parseInt(num)
  
  if (number <= 10) {
    return chineseNumbers[number]
  } else if (number < 20) {
    return '十' + (number % 10 === 0 ? '' : chineseNumbers[number % 10])
  } else if (number < 100) {
    const tens = Math.floor(number / 10)
    const ones = number % 10
    return chineseNumbers[tens] + '十' + (ones === 0 ? '' : chineseNumbers[ones])
  }
  return num.toString()
}

const handleShareClose = () => {
  showShare.value = false
}
</script>

<style scoped>
.result {
  min-height: calc(100vh - 64px);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--spacing-large);
}

.result-content {
  background: var(--color-jade-white);
  border-radius: 16px;
  padding: var(--spacing-large);
  max-width: 480px;
  width: 100%;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.05);
}

.header-wrapper {
  position: relative;
  display: flex;
  justify-content: center;
  margin-bottom: var(--spacing-medium);
  min-height: 60px;
}

.sign-info {
  display: flex;
  align-items: center;
  gap: var(--spacing-small);
}

.sign-number {
  font-family: var(--font-family-serif);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-lg);
}

.sign-name {
  font-family: var(--font-family-serif);
  color: var(--color-accent-gold);
  font-size: var(--font-size-lg);
}

.date-wrapper {
  position: absolute;
  right: 0;
  top: 0;
  display: flex;
  gap: 0.5rem;
}

.date-text, .year-text {
  font-family: var(--font-family-serif);
  color: var(--color-cloud-gray);
  font-size: var(--font-size-sm);
  opacity: 0.8;
  writing-mode: vertical-rl;
  text-orientation: upright;
  letter-spacing: 0.15em;
  line-height: 1.4;
}

.poem-section {
  margin: var(--spacing-medium) 0;
  padding: var(--spacing-medium) var(--spacing-medium);
  position: relative;
  display: flex;
  justify-content: center;
}

.poem-section::before,
.poem-section::after {
  content: '';
  position: absolute;
  width: 1px;
  height: 80%;
  top: 10%;
  background: linear-gradient(to bottom, 
    transparent 0%,
    var(--color-accent-gold) 20%,
    var(--color-accent-gold) 80%,
    transparent 100%
  );
  opacity: 0.3;
}

.poem-section::before {
  left: var(--spacing-medium);
}

.poem-section::after {
  right: var(--spacing-medium);
}

.poem {
  font-family: var(--font-family-serif);
  color: var(--color-accent-gold);
  text-align: center;
  white-space: pre-line;
  line-height: 2.2;
  font-size: var(--font-size-lg);
  position: relative;
  padding: 0 var(--spacing-large);
  max-width: 320px;
  text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.05);
}

.poem::before,
.poem::after {
  content: '"';
  position: absolute;
  font-size: var(--font-size-xxl);
  color: var(--color-accent-gold);
  opacity: 0.2;
  font-family: serif;
  line-height: 1;
}

.poem::before {
  left: 0;
  top: -0.5em;
}

.poem::after {
  right: 0;
  bottom: -0.8em;
  transform: rotate(180deg);
}

.divider {
  height: 1px;
  background: rgba(180, 161, 98, 0.2);
  margin: var(--spacing-medium) 0;
}

.interpretation-section {
  padding: 0 var(--spacing-medium);
}

.explanation {
  color: var(--color-ink-black);
  opacity: 0.75;
  line-height: 1.8;
  text-align: justify;
  font-size: var(--font-size-base);
}

.actions {
  display: flex;
  justify-content: center;
  margin-top: var(--spacing-large);
  gap: var(--spacing-medium);
}

.share-btn, .history-btn {
  padding: var(--spacing-small) var(--spacing-large);
  border-radius: 24px;
  font-family: var(--font-family-serif);
  cursor: pointer;
  transition: var(--transition-base);
  background: transparent;
  color: var(--color-cloud-gray);
  border: 1px solid currentColor;
}

.share-btn:hover, .history-btn:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}

@media (max-width: 480px) {
  .result-content {
    padding: var(--spacing-medium);
  }
  
  .poem {
    font-size: var(--font-size-base);
  }
  
  .explanation {
    font-size: var(--font-size-sm);
  }
}

.sign-level {
  font-family: var(--font-family-serif);
  color: var(--color-accent-gold);
  font-size: var(--font-size-base);
  margin-left: var(--spacing-small);
}

.error {
  min-height: calc(100vh - 64px);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--color-error);
  text-align: center;
  padding: var(--spacing-large);
}

.error button {
  margin-top: var(--spacing-medium);
  padding: var(--spacing-small) var(--spacing-large);
  border-radius: 24px;
  background: transparent;
  color: var(--color-error);
  border: 1px solid currentColor;
  cursor: pointer;
  transition: var(--transition-base);
}
</style> 