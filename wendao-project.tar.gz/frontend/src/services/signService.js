import axios from 'axios'

const API_BASE_URL = '/api'

// 添加请求拦截器
axios.interceptors.request.use(config => {
  console.log('发送请求:', config.url)
  return config
})

// 添加响应拦截器
axios.interceptors.response.use(
  response => {
    console.log('请求成功:', response.config.url, response.data)
    return response
  },
  error => {
    console.error('请求失败:', error.config?.url, error.message)
    if (error.response) {
      console.error('错误状态:', error.response.status)
      console.error('错误数据:', error.response.data)
    }
    return Promise.reject(error)
  }
)

export const signService = {
  /**
   * 获取今日签文
   * @returns {Promise<Object>} 签文对象
   */
  async getTodaySign() {
    try {
      const response = await axios.get(`${API_BASE_URL}/signs/today`);
      if (!response.data) {
        throw new Error('签文数据为空');
      }
      return response.data;
    } catch (error) {
      console.error('获取今日签文失败:', error);
      if (!error.response) {
        throw new Error('网络连接失败');
      } else if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }
      throw new Error('获取签文失败，请稍后重试');
    }
  },

  /**
   * 获取签文详情
   * @param {string} signId - 签文ID
   * @returns {Promise<Object>} 签文详情
   */
  async getSignDetail(signId) {
    try {
      const response = await axios.get(`${API_BASE_URL}/signs/${signId}`);
      return response.data;
    } catch (error) {
      console.error('获取签文详情失败:', error);
      throw new Error('获取签文详情失败');
    }
  },

  /**
   * 获取随机签文
   * @returns {Promise<Object>} 签文对象
   */
  async getRandomSign() {
    try {
      const response = await axios.get(`${API_BASE_URL}/signs/random`);
      return response.data;
    } catch (error) {
      console.error('获取随机签文失败:', error);
      throw new Error('获取随机签文失败');
    }
  }
}

export default signService 