import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Result from '../views/Result.vue'
import History from '../views/History.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      title: '玉签斋 - 在线抽签'
    }
  },
  {
    path: '/result',
    name: 'Result',
    component: Result,
    meta: {
      title: '抽签结果 - 玉签斋'
    }
  },
  {
    path: '/history',
    name: 'History',
    component: History,
    meta: {
      title: '抽签历史 - 玉签斋'
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router 