import { defineStore } from 'pinia'
import axios from '../axios'

export const useUserStore = defineStore('user', {
  state: () => ({
    token: localStorage.getItem('token') || null,
    user: null
  }),

  getters: {
    isLoggedIn: (state) => !!state.token
  },

  actions: {
    async register({ username, password }) {
      try {
        const { token, user } = await axios.post('/users/register', {
          username,
          password
        })
        
        this.token = token
        this.user = user
        localStorage.setItem('token', token)
        
        return user
      } catch (error) {
        throw error
      }
    },

    async login({ username, password }) {
      try {
        const { token, user } = await axios.post('/users/login', {
          username,
          password
        })
        
        this.token = token
        this.user = user
        localStorage.setItem('token', token)
        
        return user
      } catch (error) {
        throw error
      }
    },

    async logout() {
      this.token = null
      this.user = null
      localStorage.removeItem('token')
    },

    async getUserProfile() {
      try {
        return await axios.get('/users/profile')
      } catch (error) {
        throw error
      }
    }
  }
}) 