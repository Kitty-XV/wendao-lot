import axios from 'axios'
import { ElMessage } from 'element-plus'
import router from './router'

// 创建 axios 实例
const instance = axios.create({
  baseURL: 'http://localhost:3001/api',
  timeout: 5000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器
instance.interceptors.request.use(
  config => {
    return config
  },
  error => {
    console.error('请求拦截器错误:', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
instance.interceptors.response.use(
  response => {
    return response.data
  },
  error => {
    console.error('API请求错误:', error)
    
    if (error.code === 'ECONNABORTED') {
      ElMessage.error('请求超时，请检查网络连接')
      return Promise.reject(new Error('请求超时'))
    }
    
    if (!error.response) {
      ElMessage.error('网络连接失败，请检查网络连接或后端服务是否启动')
      return Promise.reject(new Error('网络连接失败'))
    }
    
    const { status, data } = error.response
    
    switch (status) {
      case 400:
        ElMessage.error(data.message || '请求参数错误')
        break
      case 404:
        ElMessage.error(data.message || '请求的资源不存在')
        break
      case 500:
        ElMessage.error(data.message || '服务器内部错误，请稍后重试')
        break
      default:
        ElMessage.error(data.message || '请求失败，请稍后重试')
    }
    
    return Promise.reject(error)
  }
)

export default instance 