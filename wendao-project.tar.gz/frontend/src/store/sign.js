import { defineStore } from 'pinia'

export const useSignStore = defineStore('sign', {
  state: () => {
    // 初始化状态
    try {
      const today = new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')
      const lastDrawDate = localStorage.getItem('lastDrawDate')
      const savedSign = localStorage.getItem('currentSign')
      const savedHistory = localStorage.getItem('signHistory')
      
      return {
        currentSign: savedSign ? JSON.parse(savedSign) : null,
        signHistory: savedHistory ? JSON.parse(savedHistory) : [],
        isDrawDisabled: lastDrawDate === today
      }
    } catch (error) {
      console.error('初始化状态失败:', error)
      // 如果解析失败，重置状态
      localStorage.removeItem('currentSign')
      localStorage.removeItem('signHistory')
      localStorage.removeItem('lastDrawDate')
      return {
        currentSign: null,
        signHistory: [],
        isDrawDisabled: false
      }
    }
  },

  actions: {
    setCurrentSign(sign) {
      if (!sign) return
      
      try {
        this.currentSign = sign
        localStorage.setItem('currentSign', JSON.stringify(sign))
        
        // 添加到历史记录
        const today = new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')
        const historyItem = {
          date: today,
          sign: sign
        }
        
        // 检查是否已经存在今天的记录
        const existingIndex = this.signHistory.findIndex(item => item.date === today)
        if (existingIndex !== -1) {
          // 更新今天的记录
          this.signHistory[existingIndex] = historyItem
        } else {
          // 添加新记录
          this.signHistory.unshift(historyItem)
        }
        
        // 只保留最近30天的记录
        if (this.signHistory.length > 30) {
          this.signHistory = this.signHistory.slice(0, 30)
        }
        
        // 保存到本地存储
        localStorage.setItem('signHistory', JSON.stringify(this.signHistory))
        localStorage.setItem('lastDrawDate', today)
        this.isDrawDisabled = true
      } catch (error) {
        console.error('保存签文失败:', error)
      }
    },

    // 获取历史记录，支持分页和筛选
    getHistory({ page = 1, pageSize = 10, level = null } = {}) {
      try {
        let filteredHistory = [...this.signHistory]
        
        // 按等级筛选
        if (level) {
          filteredHistory = filteredHistory.filter(item => item.sign.level === level)
        }
        
        // 计算分页
        const total = filteredHistory.length
        const start = (page - 1) * pageSize
        const end = start + pageSize
        const records = filteredHistory.slice(start, end)
        
        return {
          records,
          pagination: {
            total,
            page,
            pageSize,
            totalPages: Math.ceil(total / pageSize)
          }
        }
      } catch (error) {
        console.error('获取历史记录失败:', error)
        return {
          records: [],
          pagination: {
            total: 0,
            page: 1,
            pageSize,
            totalPages: 1
          }
        }
      }
    },

    setDrawDisabled(disabled) {
      this.isDrawDisabled = disabled
    },

    // 清理历史记录
    clearHistory() {
      this.signHistory = []
      localStorage.removeItem('signHistory')
    }
  },

  getters: {
    hasDrawnToday: (state) => state.isDrawDisabled,
    
    // 获取统计信息
    statistics: (state) => {
      const stats = {
        totalCount: state.signHistory.length,
        levelStats: {
          '上上': 0,
          '上': 0,
          '中': 0,
          '下': 0,
          '下下': 0
        },
        continuousDays: 0
      }
      
      // 计算各等级签文数量
      state.signHistory.forEach(item => {
        if (item.sign && item.sign.level) {
          stats.levelStats[item.sign.level]++
        }
      })
      
      // 计算连续抽签天数
      if (state.signHistory.length > 0) {
        const today = new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')
        let currentDate = new Date(today)
        let continuousDays = 0
        
        for (let i = 0; i < state.signHistory.length; i++) {
          const recordDate = new Date(state.signHistory[i].date)
          const dayDiff = Math.floor((currentDate - recordDate) / (1000 * 60 * 60 * 24))
          
          if (dayDiff === continuousDays) {
            continuousDays++
          } else {
            break
          }
          currentDate = recordDate
        }
        
        stats.continuousDays = continuousDays
      }
      
      return stats
    }
  }
}) 