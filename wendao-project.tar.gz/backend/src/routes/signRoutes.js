const express = require('express');
const router = express.Router();
const signService = require('../services/signService');

// 获取今日签文
router.get('/today', async (req, res) => {
    try {
        const clientId = req.ip; // 使用客户端IP作为标识
        const sign = await signService.getTodaySign(clientId);
        res.json(sign);
    } catch (error) {
        console.error('获取今日签文失败:', error);
        res.status(500).json({ message: error.message || '获取签文失败' });
    }
});

// 获取随机签文
router.get('/random', async (req, res) => {
    try {
        const sign = await signService.getRandomSign();
        if (!sign) {
            return res.status(404).json({ message: '暂无可用签文' });
        }
        res.json(sign);
    } catch (error) {
        console.error('随机抽签失败:', error);
        res.status(500).json({ message: '获取签文失败' });
    }
});

// 获取签文详情（注意：这个路由要放在最后，避免拦截其他路由）
router.get('/:id', async (req, res) => {
    try {
        const sign = await signService.getSignDetail(req.params.id);
        if (!sign) {
            return res.status(404).json({ message: '签文不存在' });
        }
        res.json(sign);
    } catch (error) {
        console.error('获取签文详情失败:', error);
        res.status(500).json({ message: '获取签文详情失败' });
    }
});

module.exports = router; 