const { 
    SignLevel, 
    getSignById, 
    getSignsByLevel, 
    getRandomSign, 
    getAllSigns, 
    searchSigns 
} = require('../data/signs');

// 用于存储每日抽签记录
const signRecords = new Map();

class SignService {
    /**
     * 获取今日签文
     * @param {string} clientId - 客户端标识（IP或会话ID）
     * @returns {Promise<Object>} 签文对象
     */
    async getTodaySign(clientId) {
        try {
            if (!clientId) {
                throw new Error('客户端标识不能为空');
            }

            const today = new Date().toISOString().split('T')[0];
            const recordKey = `${clientId}_${today}`;
            
            // 检查今日是否已抽签
            if (signRecords.has(recordKey)) {
                const savedSign = signRecords.get(recordKey);
                if (!savedSign) {
                    throw new Error('保存的签文数据无效');
                }
                return savedSign;
            }
            
            // 随机抽取新签文
            const sign = getRandomSign();
            if (!sign) {
                throw new Error('获取签文失败');
            }
            
            // 保存今日抽签记录
            signRecords.set(recordKey, sign);
            
            // 清理过期记录
            this.cleanupOldRecords();
            
            return sign;
        } catch (error) {
            throw error;
        }
    }

    /**
     * 获取签文详情
     * @param {string} signId - 签文ID
     * @returns {Promise<Object>} 签文详情
     */
    async getSignDetail(signId) {
        return getSignById(signId);
    }

    /**
     * 搜索签文
     * @param {string} keyword - 搜索关键词
     * @returns {Promise<Array>} 签文列表
     */
    async searchSigns(keyword) {
        return searchSigns(keyword);
    }

    /**
     * 获取指定等级的签文
     * @param {string} level - 签文等级
     * @returns {Promise<Array>} 签文列表
     */
    async getSignsByLevel(level) {
        return getSignsByLevel(level);
    }

    /**
     * 清理过期记录
     * @private
     */
    cleanupOldRecords() {
        const today = new Date().toISOString().split('T')[0];
        for (const [key] of signRecords) {
            const [, recordDate] = key.split('_');
            if (recordDate !== today) {
                signRecords.delete(key);
            }
        }
    }

    /**
     * 获取随机签文
     * @returns {Promise<Object>} 签文对象
     */
    async getRandomSign() {
        return getRandomSign();
    }
}

module.exports = new SignService(); 