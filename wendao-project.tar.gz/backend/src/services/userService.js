const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const db = require('../models/database')
const { JWT_SECRET, JWT_EXPIRES_IN } = require('../config/auth')

class UserService {
  // 注册新用户
  async register(username, password, email) {
    try {
      // 检查用户名是否已存在
      const existingUser = await db.get('SELECT id FROM users WHERE username = ?', [username])
      if (existingUser) {
        throw new Error('用户名已存在')
      }

      // 检查邮箱是否已存在
      if (email) {
        const existingEmail = await db.get('SELECT id FROM users WHERE email = ?', [email])
        if (existingEmail) {
          throw new Error('邮箱已被使用')
        }
      }

      // 密码加密
      const hashedPassword = await bcrypt.hash(password, 10)

      // 插入新用户
      const result = await db.run(
        'INSERT INTO users (username, password, email, total_days, continuous_days) VALUES (?, ?, ?, 0, 0)',
        [username, hashedPassword, email]
      )

      // 生成 token
      const token = jwt.sign(
        { id: result.id, username },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRES_IN }
      )

      return {
        token,
        user: {
          id: result.id,
          username,
          email,
          created_at: new Date().toISOString(),
          total_days: 0,
          continuous_days: 0
        }
      }
    } catch (error) {
      console.error('注册失败:', error)
      throw error
    }
  }

  // 用户登录
  async login(username, password) {
    try {
      // 查找用户
      const user = await db.get('SELECT * FROM users WHERE username = ?', [username])
      if (!user) {
        throw new Error('用户不存在')
      }

      // 验证密码
      const isValidPassword = await bcrypt.compare(password, user.password)
      if (!isValidPassword) {
        throw new Error('密码错误')
      }

      // 生成 JWT token
      const token = jwt.sign(
        { id: user.id, username: user.username },
        JWT_SECRET,
        { expiresIn: JWT_EXPIRES_IN }
      )

      return {
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          created_at: user.created_at,
          avatar: user.avatar,
          total_days: user.total_days,
          continuous_days: user.continuous_days
        }
      }
    } catch (error) {
      console.error('登录失败:', error)
      throw error
    }
  }

  // 获取用户信息
  async getUserProfile(userId) {
    try {
      // 获取基本信息
      const user = await db.get(
        'SELECT id, username, email, created_at, avatar, total_days, continuous_days FROM users WHERE id = ?',
        [userId]
      )

      if (!user) {
        throw new Error('用户不存在')
      }

      // 获取运势分布统计
      const levelStats = await db.all(`
        SELECT signs.level, COUNT(*) as count
        FROM sign_history
        JOIN signs ON sign_history.sign_id = signs.id
        WHERE sign_history.user_id = ?
        GROUP BY signs.level
      `, [userId])

      // 格式化运势分布数据
      const formattedLevelStats = {
        '上上': 0,
        '上': 0,
        '中': 0,
        '下': 0,
        '下下': 0
      }

      levelStats.forEach(stat => {
        formattedLevelStats[stat.level] = stat.count
      })

      return {
        ...user,
        levelStats: formattedLevelStats
      }
    } catch (error) {
      console.error('获取用户信息失败:', error)
      throw error
    }
  }
}

module.exports = new UserService() 