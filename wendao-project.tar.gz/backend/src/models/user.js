const { db } = require('./database')

// 创建用户表
const createUserTable = async () => {
  const sql = `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      avatar TEXT DEFAULT NULL,
      total_days INTEGER DEFAULT 0,
      continuous_days INTEGER DEFAULT 0,
      last_sign_date DATE DEFAULT NULL
    )
  `
  await db.run(sql)
}

// 创建抽签历史表
const createSignHistoryTable = async () => {
  const sql = `
    CREATE TABLE IF NOT EXISTS sign_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      sign_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id),
      FOREIGN KEY (sign_id) REFERENCES signs (id)
    )
  `
  await db.run(sql)
}

// 初始化数据库表
const initDatabase = async () => {
  await createUserTable()
  await createSignHistoryTable()
}

module.exports = {
  initDatabase
} 