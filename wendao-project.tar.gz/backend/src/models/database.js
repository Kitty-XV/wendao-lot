const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// 确保数据目录存在
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true, mode: 0o777 });
}

const dbPath = path.join(dataDir, 'database.sqlite');

// 如果数据库文件不存在，创建它并设置权限
if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, '', { mode: 0o666 });
}

const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
    if (err) {
        console.error('数据库连接失败:', err.message);
    } else {
        console.log('成功连接到数据库');
        initDatabase();
    }
});

// 初始化数据库表
async function initDatabase() {
    try {
        // 创建用户表
        await run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                email TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                avatar TEXT,
                total_days INTEGER DEFAULT 0,
                continuous_days INTEGER DEFAULT 0,
                last_sign_date DATE
            )
        `);
        console.log('用户表创建成功或已存在');

        // 创建抽签记录表
        await run(`
            CREATE TABLE IF NOT EXISTS sign_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                sign_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        `);
        console.log('抽签记录表创建成功或已存在');

        // 创建签文表
        await run(`
            CREATE TABLE IF NOT EXISTS signs (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                level TEXT NOT NULL,
                poem TEXT NOT NULL,
                explanation TEXT NOT NULL,
                interpretation TEXT NOT NULL,
                advice TEXT NOT NULL
            )
        `);
        console.log('签文表创建成功或已存在');

        // 初始化签文数据
        const signsCount = await get('SELECT COUNT(*) as count FROM signs');
        if (signsCount.count === 0) {
            const { signs } = require('../data/signs');
            for (const sign of signs) {
                await run(
                    'INSERT INTO signs (id, name, level, poem, explanation, interpretation, advice) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [sign.id, sign.name, sign.level, sign.poem, sign.explanation, sign.interpretation, sign.advice]
                );
            }
            console.log('签文数据初始化成功');
        }

    } catch (error) {
        console.error('初始化数据库失败:', error);
    }
}

// Promise 封装的数据库操作
function run(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) {
                console.error('SQL执行错误:', err);
                reject(err);
            } else {
                resolve({ id: this.lastID, changes: this.changes });
            }
        });
    });
}

function get(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) {
                console.error('SQL执行错误:', err);
                reject(err);
            } else {
                resolve(row);
            }
        });
    });
}

function all(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) {
                console.error('SQL执行错误:', err);
                reject(err);
            } else {
                resolve(rows);
            }
        });
    });
}

module.exports = {
    run,
    get,
    all,
    close: () => {
        return new Promise((resolve, reject) => {
            db.close(err => {
                if (err) {
                    console.error('关闭数据库失败:', err);
                    reject(err);
                } else {
                    resolve();
                }
            });
        });
    }
}; 