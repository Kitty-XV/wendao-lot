# 玉签斋 Web版

一个优雅的在线抽签应用，让传统文化在现代网络中焕发新生。

## 功能特点

- 🎯 每日抽签
- 📜 详细解签
- 🤖 AI问答
- 📊 历史记录
- 👤 用户系统

## 快速开始

### 前端启动

```bash
cd frontend
npm install
npm run dev
```

访问 http://localhost:5173

### 后端启动

```bash
cd backend
npm install
npm run dev
```

服务将在 http://localhost:3000 启动

## 环境要求

- Node.js >= 16
- NPM >= 8
- SQLite3

## 项目配置

1. 复制环境变量文件
```bash
cp .env.example .env
```

2. 修改环境变量
```env
JWT_SECRET=your_secret_key
AI_API_KEY=your_api_key
```

## 开发指南

- 遵循 Vue3 组合式API规范
- 使用ESLint进行代码规范检查
- 提交前运行测试 `npm run test`

## 部署

### 前端部署（Vercel）

1. Fork 本仓库
2. 在Vercel中导入项目
3. 设置环境变量
4. 完成部署

### 后端部署（Railway）

1. 创建Railway项目
2. 关联GitHub仓库
3. 配置环境变量
4. 启动服务

## 贡献指南

1. Fork 本仓库
2. 创建特性分支
3. 提交变更
4. 发起 Pull Request

## 许可证

MIT License 