# 玉签斋 Web应用设计文档

## 1. 项目概述

玉签斋是一个简约优雅的在线抽签应用，让用户可以在网页上体验传统抽签文化。

### 1.1 核心功能
- 每日抽签
- 签文解读
- 历史记录查看
- 用户系统

## 2. 技术栈选择

采用轻量级的技术栈，保持简单易维护：

### 2.1 前端
- HTML5 + CSS3 + JavaScript
- Vue.js 3 (无需Vuex，使用组合式API)
- TailwindCSS (样式框架)
- Axios (HTTP请求)

### 2.2 后端
- Node.js + Express
- SQLite (轻量级数据库)
- JWT (用户认证)

### 2.3 部署
- Vercel (前端部署)
- Railway (后端部署)

## 3. 项目结构

```
web-yuqianzhai/
├── frontend/          # 前端代码
│   ├── src/
│   │   ├── components/   # 组件
│   │   ├── views/       # 页面
│   │   ├── assets/      # 静态资源
│   │   └── api/         # API调用
│   └── public/          # 公共资源
├── backend/           # 后端代码
│   ├── src/
│   │   ├── routes/      # 路由
│   │   ├── models/      # 数据模型
│   │   └── services/    # 业务逻辑
│   └── data/           # 签文数据
└── docs/             # 文档
```

## 4. 数据模型

### 4.1 用户表 (Users)
```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL,
  email TEXT UNIQUE,
  password_hash TEXT,
  created_at DATETIME,
  last_sign_date DATE
);
```

### 4.2 签文历史表 (SignHistory)
```sql
CREATE TABLE sign_history (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  sign_id INTEGER,
  sign_date DATE,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

## 5. 页面设计

### 5.1 首页 (/)
- 云纹背景动效
- 抽签按钮
- 每日限制提示
- 登录状态展示

### 5.2 结果页 (/result)
- 签文展示
- 诗句与解签
- AI解答区域
- 分享功能

### 5.3 历史记录 (/history)
- 时间轴展示
- 签文列表
- 筛选功能

### 5.4 个人中心 (/profile)
- 用户信息
- 统计数据
- 设置选项

## 6. API接口设计

### 6.1 用户相关
- POST /api/auth/register - 注册
- POST /api/auth/login - 登录
- GET /api/auth/profile - 获取用户信息

### 6.2 抽签相关
- POST /api/sign/draw - 抽签
- GET /api/sign/history - 获取历史记录
- GET /api/sign/today - 获取今日抽签状态

### 6.3 AI问答
- POST /api/ai/ask - 提交问题
- GET /api/ai/history - 获取问答历史

## 7. 样式主题

### 7.1 配色方案
```css
:root {
  --primary: #8b4513;    /* 主色调：褐色 */
  --secondary: #f5e6d3;  /* 背景色：米色 */
  --text: #2c1810;      /* 文字色：深褐色 */
  --accent: #d4a017;    /* 强调色：金色 */
}
```

### 7.2 字体选择
- 主要字体：楷体
- 副标题：仿宋
- 正文：思源宋体

## 8. 部署说明

1. 前端部署
   - 构建命令：`npm run build`
   - 输出目录：`dist/`
   - Vercel自动部署

2. 后端部署
   - Railway平台
   - 环境变量配置
   - 数据库备份策略

## 9. 开发计划

### 第一阶段（1周）
- [x] 项目基础搭建
- [x] 用户系统开发
- [x] 基础UI组件

### 第二阶段（1周）
- [ ] 抽签核心功能
- [ ] 历史记录
- [ ] 数据库对接

### 第三阶段（1周）
- [ ] AI问答集成
- [ ] UI美化
- [ ] 部署上线

## 10. 注意事项

1. 保持代码简洁，避免过度工程化
2. 注重用户体验，保持操作流畅
3. 确保移动端适配
4. 实现渐进式加载
5. 做好错误处理和用户提示 